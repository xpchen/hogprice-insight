<template>
  <el-container class="layout-container">
    <el-aside :width="isCollapse ? '64px' : '220px'" class="sidebar">
      <div class="logo">
        <img src="@/assets/logo.png" alt="HOGPRICE" class="logo-img" />
        <span v-if="!isCollapse" class="logo-text">猪价智盘</span>
        <span v-else class="logo-text-collapsed">智盘</span>
      </div>
      <el-menu
        :default-active="activeMenu"
        router
        class="sidebar-menu"
        :collapse="isCollapse"
        :collapse-transition="false"
      >
        <!-- A. 看板（客户每日入口） -->
        <el-sub-menu index="dashboard-group">
          <template #title>
            <el-icon><House /></el-icon>
            <span>看板</span>
          </template>
          <el-menu-item index="/dashboard">
            <el-icon><House /></el-icon>
            <template #title>行情总览</template>
          </el-menu-item>
          <el-menu-item index="/price">
            <el-icon><TrendCharts /></el-icon>
            <template #title>价格</template>
          </el-menu-item>
          <el-menu-item index="/slaughter">
            <el-icon><DataAnalysis /></el-icon>
            <template #title>屠宰</template>
          </el-menu-item>
          <el-menu-item index="/weight">
            <el-icon><DataAnalysis /></el-icon>
            <template #title>均重</template>
          </el-menu-item>
          <el-menu-item index="/frozen">
            <el-icon><DataAnalysis /></el-icon>
            <template #title>冻品</template>
          </el-menu-item>
          <el-menu-item index="/industry-chain">
            <el-icon><DataAnalysis /></el-icon>
            <template #title>产业链</template>
          </el-menu-item>
        </el-sub-menu>

        <!-- B. 期货期权 -->
        <el-sub-menu index="futures-group">
          <template #title>
            <el-icon><TrendCharts /></el-icon>
            <span>期货期权</span>
          </template>
          <el-menu-item index="/futures">
            <el-icon><TrendCharts /></el-icon>
            <template #title>生猪期货</template>
          </el-menu-item>
          <el-menu-item index="/options">
            <el-icon><TrendCharts /></el-icon>
            <template #title>生猪期权</template>
          </el-menu-item>
        </el-sub-menu>

        <!-- C. 分析与预警 -->
        <el-sub-menu index="analysis-group">
          <template #title>
            <el-icon><DataAnalysis /></el-icon>
            <span>分析与预警</span>
          </template>
          <el-menu-item index="/analysis">
            <el-icon><DataAnalysis /></el-icon>
            <template #title>多维分析</template>
          </el-menu-item>
          <el-menu-item index="/chart-builder">
            <el-icon><DataAnalysis /></el-icon>
            <template #title>图表配置</template>
          </el-menu-item>
          <el-menu-item index="/template-center">
            <el-icon><Document /></el-icon>
            <template #title>模板中心</template>
          </el-menu-item>
        </el-sub-menu>

        <!-- D. 数据导入（所有用户可见） -->
        <el-menu-item index="/data-ingest" class="data-import-item">
          <el-icon><Upload /></el-icon>
          <template #title>数据导入</template>
        </el-menu-item>

        <!-- E. 报表与导出 -->
        <el-sub-menu index="reports-group">
          <template #title>
            <el-icon><Document /></el-icon>
            <span>报表与导出</span>
          </template>
          <el-menu-item index="/reports">
            <el-icon><Document /></el-icon>
            <template #title>报告生成</template>
          </el-menu-item>
        </el-sub-menu>

        <!-- F. 数据中心（仅管理员/运营可见） -->
        <el-sub-menu v-if="isAdminOrOperator" index="data-center-group">
          <template #title>
            <el-icon><Setting /></el-icon>
            <span>数据中心</span>
          </template>
          <el-menu-item index="/data-reconciliation">
            <el-icon><DataAnalysis /></el-icon>
            <template #title>入库对账</template>
          </el-menu-item>
          <el-menu-item index="/import">
            <el-icon><Upload /></el-icon>
            <template #title>数据导入（旧）</template>
          </el-menu-item>
        </el-sub-menu>

        <!-- G. 系统管理（仅管理员可见） -->
        <el-sub-menu v-if="isAdmin" index="system-group">
          <template #title>
            <el-icon><Setting /></el-icon>
            <span>系统管理</span>
          </template>
          <el-menu-item index="/templates">
            <el-icon><Document /></el-icon>
            <template #title>模板管理</template>
          </el-menu-item>
        </el-sub-menu>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header class="header">
        <div class="header-left">
          <el-button
            :icon="isCollapse ? Expand : Fold"
            circle
            @click="toggleCollapse"
            style="margin-right: 10px"
          />
        </div>
        <div class="header-right">
          <el-tooltip :content="isFullscreen ? '退出全屏 (Esc)' : '全屏 (F11)'" placement="bottom">
            <el-button
              :icon="FullScreen"
              circle
              @click="toggleFullscreen"
              :type="isFullscreen ? 'warning' : 'default'"
              style="margin-right: 10px"
            />
          </el-tooltip>
          <span>{{ userStore.user?.username }}</span>
          <el-button type="text" @click="handleLogout">退出</el-button>
        </div>
      </el-header>
      <el-main>
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { House, Upload, DataAnalysis, Fold, Expand, FullScreen, Document, TrendCharts, Setting } from '@element-plus/icons-vue'
import { useUserStore } from '../store/user'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const activeMenu = computed(() => route.path)
const isCollapse = ref(false)
const isFullscreen = ref(false)

// 权限判断
const isAdmin = computed(() => {
  const roles = userStore.user?.roles || []
  return roles.includes('admin') || roles.some((r: any) => r.code === 'admin')
})

const isAdminOrOperator = computed(() => {
  const roles = userStore.user?.roles || []
  return isAdmin.value || roles.includes('operator') || roles.some((r: any) => r.code === 'operator')
})

// 切换侧边栏折叠
const toggleCollapse = () => {
  isCollapse.value = !isCollapse.value
}

// 切换全屏
const toggleFullscreen = () => {
  if (!document.fullscreenElement) {
    // 进入全屏
    document.documentElement.requestFullscreen().then(() => {
      isFullscreen.value = true
      ElMessage.success('已进入全屏模式')
    }).catch((err) => {
      console.error('无法进入全屏:', err)
      ElMessage.error('无法进入全屏模式')
    })
  } else {
    // 退出全屏
    document.exitFullscreen().then(() => {
      isFullscreen.value = false
      ElMessage.success('已退出全屏模式')
    }).catch((err) => {
      console.error('无法退出全屏:', err)
    })
  }
}

// 监听全屏状态变化
const handleFullscreenChange = () => {
  isFullscreen.value = !!document.fullscreenElement
}

onMounted(() => {
  // 检查当前是否全屏
  isFullscreen.value = !!document.fullscreenElement
  // 监听全屏状态变化
  document.addEventListener('fullscreenchange', handleFullscreenChange)
})

onUnmounted(() => {
  document.removeEventListener('fullscreenchange', handleFullscreenChange)
})

const handleLogout = () => {
  userStore.clearToken()
  ElMessage.success('已退出登录')
  router.push('/login')
}
</script>

<style scoped>
.layout-container {
  height: 100vh;
}

.sidebar {
  background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
  color: #fff;
  box-shadow: 2px 0 8px rgba(0, 0, 0, 0.1);
}

.logo {
  height: 64px;
  line-height: 64px;
  text-align: center;
  font-size: 18px;
  font-weight: 600;
  color: #fff;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 0 16px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  transition: all 0.3s ease;
}

.logo:hover {
  background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
}

.logo-img {
  height: 40px;
  width: auto;
  object-fit: contain;
  flex-shrink: 0;
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
}

.logo-text {
  font-size: 18px;
  white-space: nowrap;
  flex-shrink: 0;
  letter-spacing: 1px;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.logo-text-collapsed {
  font-size: 16px;
  white-space: nowrap;
  flex-shrink: 0;
  font-weight: 600;
}

.sidebar-menu {
  border: none;
  background-color: transparent;
  padding: 8px 0;
}

/* 菜单项基础样式 */
.sidebar-menu :deep(.el-menu-item),
.sidebar-menu :deep(.el-sub-menu__title) {
  color: #cbd5e1;
  height: 48px;
  line-height: 48px;
  margin: 4px 8px;
  border-radius: 8px;
  transition: all 0.3s ease;
  font-size: 14px;
}

.sidebar-menu :deep(.el-menu-item:hover),
.sidebar-menu :deep(.el-sub-menu__title:hover) {
  background-color: rgba(255, 255, 255, 0.08);
  color: #fff;
}

.sidebar-menu :deep(.el-menu-item.is-active) {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: #fff;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
  font-weight: 500;
}

/* 数据导入菜单项特殊样式 */
.sidebar-menu :deep(.data-import-item) {
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
  color: #fff;
  margin: 8px;
  font-weight: 500;
  box-shadow: 0 4px 12px rgba(245, 87, 108, 0.3);
}

.sidebar-menu :deep(.data-import-item:hover) {
  background: linear-gradient(135deg, #f5576c 0%, #f093fb 100%);
  box-shadow: 0 6px 16px rgba(245, 87, 108, 0.4);
  transform: translateY(-1px);
}

.sidebar-menu :deep(.data-import-item.is-active) {
  background: linear-gradient(135deg, #f5576c 0%, #f093fb 100%);
  box-shadow: 0 6px 16px rgba(245, 87, 108, 0.5);
}

/* 子菜单样式 */
.sidebar-menu :deep(.el-sub-menu) {
  margin: 4px 8px;
}

.sidebar-menu :deep(.el-sub-menu .el-menu-item) {
  margin: 2px 0;
  padding-left: 48px !important;
  background-color: rgba(255, 255, 255, 0.03);
}

.sidebar-menu :deep(.el-sub-menu .el-menu-item:hover) {
  background-color: rgba(255, 255, 255, 0.1);
  padding-left: 52px !important;
}

.sidebar-menu :deep(.el-sub-menu .el-menu-item.is-active) {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: #fff;
}

/* 图标样式 */
.sidebar-menu :deep(.el-icon) {
  font-size: 18px;
  margin-right: 8px;
  transition: transform 0.3s ease;
}

.sidebar-menu :deep(.el-menu-item:hover .el-icon),
.sidebar-menu :deep(.el-sub-menu__title:hover .el-icon) {
  transform: scale(1.1);
}

/* 分隔线 */
.sidebar-menu :deep(.el-menu-item) + .el-sub-menu,
.sidebar-menu :deep(.el-sub-menu) + .el-menu-item,
.sidebar-menu :deep(.el-menu-item) + .el-menu-item {
  margin-top: 4px;
}

/* 折叠状态 */
.sidebar-menu:not(.el-menu--collapse) {
  width: 220px;
}

.header {
  background: linear-gradient(90deg, #ffffff 0%, #f8fafc 100%);
  border-bottom: 1px solid #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  height: 64px;
}

.header-left {
  display: flex;
  align-items: center;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
  font-size: 14px;
  color: #475569;
}

.header-right span {
  font-weight: 500;
}

/* 响应式调整 */
@media (max-width: 768px) {
  .sidebar {
    width: 200px !important;
  }
  
  .logo-text {
    font-size: 16px;
  }
}
</style>
